package hooks;

import java.io.FileNotFoundException;
import java.util.Properties;



import com.in.utilities.DriverManager;
import com.in.utilities.FrameworkParameters;
import com.in.utilities.Settings;

import io.cucumber.java.After;
import io.cucumber.java.Before;
import io.cucumber.java.Scenario;
import reusableLibrary.CoreUtils;

public class GlobalHooks {
	
	
	public static Scenario scenario;
	public static boolean dunit=false;
	public FrameworkParameters frmeworkParameters=FrameworkParameters.getInstance();
	public static Properties props;
	
	
	@Before(order=0)
	public void beforell() {
		if(!dunit) {
			Runtime.getRuntime().addShutdownHook(new Thread());
			dunit=true;
			
		}
	}
	
	@Before(order=1)
	public void beforeScenario(Scenario scenario)throws FileNotFoundException{
		props=Settings.getInstance();
		DriverManager.getInstance().setScenario(scenario);
		String feature=scenario.getId().split(";")[0];
		DriverManager.getInstance().setFeatureName(feature.substring(feature.indexOf("features/")+9,feature.indexOf(".feature")));
		DriverManager.getInstance().setScenarioName(scenario.getName());
		
		new CoreUtils().initializeData();
		new CoreUtils().initializeProperties();
		new CoreUtils().initializeWebDriver();
		
	}
	
	
	@After
	public void afterScenario(Scenario scenario) {
		CoreUtils.getDriver().quit();
		
	}
	
	
	

}
