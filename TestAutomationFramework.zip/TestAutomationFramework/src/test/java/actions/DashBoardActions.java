package actions;

import java.text.NumberFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.Duration;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.cucumber.adapter.ExtentCucumberAdapter;
import com.aventstack.extentreports.markuputils.ExtentColor;
import com.aventstack.extentreports.markuputils.MarkupHelper;

import org.apache.xml.security.utils.Signature11ElementProxy;
import org.json.simple.JSONObject;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.aventstack.extentreports.reporter.ReporterConfigurable;

import pageObjects.ModularObjects;
import reusableLibrary.CoreUtils;

public class DashBoardActions extends CoreUtils {
	JSONObject pageData;
	ExtentReports extent = new ExtentReports();
	ExtentTest test;
	
	public DashBoardActions() {
		String clssName = DashBoardActions.class.getSimpleName();
		System.out.println("className" + clssName);
		setPageData(clssName);
		pageData = getPageData(clssName);

	}

	public void navigateAndValidate(String section) {
		checkIfAvailable(ModularObjects.generateXpathByText(section));
	}

	public void user_list_projects(String val) throws ParseException {
		test = extent.createTest("captureScreenshot");
		List<String> projects = new ArrayList<>();
		List<WebElement> rows = findElement(ModularObjects.generateXpathTable("role", "table"))
				.findElements(By.tagName("tr"));
		Double base = Double.parseDouble(val.replace("$", "").replace(",", ""));
		System.out.println(rows.size());
		for (int i = 0; i < rows.size(); i++) {
			List<WebElement> cols = rows.get(i).findElements(By.tagName("td"));
			if (!cols.get(2).getText().equalsIgnoreCase("Not set")) {
				String dollarval = cols.get(2).getText().replace("$", "").replace(",", "");
				Double conveteddollar = Double.parseDouble(dollarval);

				System.out.println(conveteddollar);
				System.out.println(base);
				if (conveteddollar > base) {

					String projName = findElement("//*[text()='" + cols.get(2).getText() + "']//preceding::td[2]")
							.getText();
					projects.add(projName);
				}

			}

		}
		
		System.out.println("List of projects having val greater thanc" + val + ":" + projects);
		ExtentCucumberAdapter.addTestStepLog("List of projects having val greater thanc" + val + ":" + projects);
		
	}

	public void get_sales_number(String month, String parameter) throws InterruptedException {
		WebElement ele = findElement("(//*[local-name()='svg'])[21]");

		int getTopLeftY = ((ele.getSize().getHeight() / 2)) - ele.getSize().getHeight();
		int getTopLeftX = ((ele.getSize().getWidth() / 2)) - ele.getSize().getWidth();

		Actions action = new Actions(getDriver());

		for (int i = 0; i < 9; i++) {

			action.moveToElement(ele, getTopLeftX + 50 * i, 0).perform();
			if (i == 8) {
				System.out.println("Sales number for " + parameter + ":"
						+ getText("//*[text()='" + parameter + "']//following::span[1]"));
				ExtentCucumberAdapter.addTestStepLog("Sales number for " + parameter + ":"
						+ getText("//*[text()='" + parameter + "']//following::span[1]"));

			}
		}

	}

	public void get_new_orders_from_current_month() {
		int count = 0;
		SimpleDateFormat sdf = new SimpleDateFormat("MMM");
		String mon = sdf.format(new Date());
		System.out.println("mon ths is" + mon);

		List<WebElement> eles = findElements("//div[@class='css-k84z30']");
		for (WebElement ele : eles) {
			// System.out.println(ele.getText());
			if (ele.getText().contains("New order") && ele.getText().contains(mon.toUpperCase())) {
				System.out.println(ele.getText());
				count++;
			}

		}
		System.out.println("Number of orders for current month is:" + count);
		ExtentCucumberAdapter.addTestStepLog("Number of orders for current month is:" + count);
	}

	public void get_authors_online() {
		int counter = 1;
		List<String> authors = new ArrayList<>();
		List<WebElement> rows = findElement("//*[@class='chakra-table css-q1xguc']/tbody")
				.findElements(By.tagName("tr"));
		System.out.println(rows.size());
		for (int i = 0; i < rows.size(); i++) {
			List<WebElement> cols = rows.get(i).findElements(By.tagName("td"));

			if (cols.get(2).getText().contains("Online")) {
				String authName = findElement(("(//*[text()='" + cols.get(2).getText() + "'])[" + (counter)
						+ "]//preceding::td[2]//following::p[1]")).getText();
				System.out.println(authName);
				authors.add(authName);
				counter++;
			}

		}
		System.out.println("List of authors online " + authors);
		ExtentCucumberAdapter.addTestStepLog("List of authors online " + authors);

	}

	public void move_to_submenu(String submenu) throws InterruptedException {
		new WebDriverWait(getDriver(),2).until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[contains(text(),'" + submenu + "')]")));
		findElement("//*[contains(text(),'" + submenu + "')]").click();
		

	}

	public void get_completed_projects() {
		int counter = 1;
		List<String> projects = new ArrayList<>();
		List<WebElement> rows = findElement("(//*[@class='chakra-table css-q1xguc'])[2]/tbody")
				.findElements(By.tagName("tr"));
		System.out.println(rows.size());
		for (int i = 0; i < rows.size(); i++) {
			List<WebElement> cols = rows.get(i).findElements(By.tagName("td"));

			if (cols.get(2).getText().contains("Done")) {
				String proj = findElement(("(//*[text()='" + cols.get(2).getText() + "'])[" + (counter)
						+ "]//preceding::td[2]//following::p[1]")).getText();
				System.out.println(proj);
				projects.add(proj);
				counter++;
			}

		}
		System.out.println("List of completed projects" + projects);
		ExtentCucumberAdapter.addTestStepLog("List of completed projects" + projects);
	}

}
