package pageObjects;

public class ModularObjects {
	
	public static String generateXpathByText(String text) {
		return "//*[text()='"+text+"']";
	}
	
	public static String generateXpathTable(String identifier,String val) {
		//*[@role='table']
		return "//*[@"+identifier+"='"+val+"']/tbody";
	}

}
