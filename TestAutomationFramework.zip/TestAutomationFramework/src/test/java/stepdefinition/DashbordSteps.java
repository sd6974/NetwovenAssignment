package stepdefinition;

import java.text.ParseException;

import com.in.utilities.Settings;

import actions.DashBoardActions;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.And;
//import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;



public class DashbordSteps extends DashBoardActions{

	
	@Given("^User launches the URL$")
	public void user_launches_url() {
		getURL(Settings.getProps().getProperty("URL"));
		
	}
	
	@And("^User validates \"([^\"]*)\" section$")
	public void user_validtes_section(String section) {
		navigateAndValidate(section);
	   
	}
	
	@And ("^User navigates to \"([^\"]*)\" section$")
	public void user_navigtes_to_section(String submenu) throws InterruptedException {
		
		move_to_submenu(submenu);
	}
	
	
	
	@Then("^User lists out the projects with budget more than \"([^\"]*)\"$")
	public void user_list_projects_with_budget(String value) throws ParseException {
		user_list_projects(value);
	}
	
	@Then("^User find out sales number for the month of \\\"([^\"]*)\" through \"([^\"]*)\"$")
	public void user_find_sales_number(String month,String parameter) throws InterruptedException {
		get_sales_number(month,parameter);
	}
	
	@Then("^User find out number of New orders for the current month$")
	public void user_find_new_orders_current_month() {
		get_new_orders_from_current_month();
	}
	
	@Then("^User find out number of authors that are online$")
	public void find_aauthors_online() {
		get_authors_online();
	}
	
	
	@Then ("^User find out projects that are complete$")
	public void find_complete_projects() {
		get_completed_projects();
	}

	
	

	
}
