package reusableLibrary;


public interface CoreUtilsInterface {
	
	public void actionMoveMouseToElement(String xpath);
	public boolean checkIfAvailable(String xpath);
	public void actionSelect(String xpath,String condition);
	public void actionClear(String xpath);
	

}
