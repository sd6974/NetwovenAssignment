package reusableLibrary;


import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.remote.RemoteWebDriver;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import com.in.utilities.DriverManager;
import com.in.utilities.Settings;

import io.github.bonigarcia.wdm.WebDriverManager;

public class CoreUtils extends SecurityManager implements CoreUtilsInterface {

	public static Properties props;

	@Override
	public void actionMoveMouseToElement(String xpath) {
		// TODO Auto-generated method stub

	}

	@Override
	public boolean checkIfAvailable(String xpath) {
		// TODO Auto-generated method stub

		try {
			return findElement(xpath).isDisplayed();
		} catch (Exception ex) {
			return false;
		}

	}

	public WebElement findElement(String xpath) {
		WebElement ele = getDriver().findElement(By.xpath(xpath));
		return ele;

	}
	
	public List<WebElement> findElements(String xpath) {
		List<WebElement> eles = getDriver().findElements(By.xpath(xpath));
		return eles;

	}

	public static WebDriver getDriver() {
		return DriverManager.getInstance().getWebDriver();
	}

	@Override
	public void actionSelect(String xpath, String condition) {
		// TODO Auto-generated method stub

	}
	
	public void clickIt(String xpath) {
		getDriver().findElement(By.xpath(xpath)).click();
	}
	public void getURL(String url) {
		getDriver().get(url);
	}

	@Override
	public void actionClear(String xpath) {
		// TODO Auto-generated method stub

	}
	
	
	public void jsScrollToElement(String xpth) {
		JavascriptExecutor js=(JavascriptExecutor)getDriver();
		WebElement ele=findElement(xpth);
		js.executeScript("arguments[0].scrollIntoView();",ele);
		
		
	}
	
	public void mouseHover(String xpath) {
		Actions action=new Actions(getDriver());
		WebElement ele=findElement(xpath);
		action.moveToElement(ele);
	}
	
	public void actionClick(String xpath) {
		Actions action=new Actions(getDriver());
		WebElement ele=findElement(xpath);
		action.moveToElement(ele).click();
	}
	public String getText(String xpath) {
		return  getDriver().findElement(By.xpath(xpath)).getText();
	}
	
	

	public static String putData(String key, String data, JSONObject pageData) {
		try {
			return pageData.put(key, data).toString();
		} catch (Exception e) {
			return null;
		}

	}

	public static void setPageData(String className) {
		DriverManager.getInstance().setPageData(getPageData(className));
	}

	public static JSONObject getPageData(String className) {
		try {
			return (JSONObject) DriverManager.getInstance().getJSON().get(className);
		} catch (Exception e) {
			System.out.println("No JSON Data found for : " + className + " page");
		}
		return null;
	}

	public void initializeData() {
		String pathName = new File(System.getProperty("user.dir") + "/src/test/resources/FeatureData/"
				+ DriverManager.getInstance().getFeatureName() + ".json").getAbsolutePath();
		String temp = DriverManager.getInstance().getScenarioName();

		ClassLoader ploader = Thread.currentThread().getContextClassLoader();
		InputStream is = ploader.getResourceAsStream(pathName);
		JSONParser prser = new JSONParser();
		try {
			JSONObject jo = (JSONObject) new JSONParser().parse(new FileReader(pathName));
			Map scenario = ((Map) jo.get(temp));
			DriverManager.getInstance().setJSON((Map) jo.get(temp));
			Iterator<Map.Entry> itr1 = scenario.entrySet().iterator();
			while (itr1.hasNext()) {
				Map.Entry pair = itr1.next();
				System.out.println(pair.getKey() + ":" + pair.getValue());

			}

		} catch (Exception ex) {
			ex.printStackTrace();
			System.out.println("Feature/Scenario Data not found" + pathName + "\nScenario name:"
					+ DriverManager.getInstance().getScenarioName());

		}

	}

	public static String getData(String data, JSONObject pageData) {
		try {
			return pageData.get(data).toString();

		} catch (Exception ex) {
			System.out.println("Key:" + data + "isn't present in page object");
		}
		return null;
	}

	public void initializeProperties() throws FileNotFoundException {
		Properties props = new Properties();
		ClassLoader loader = Thread.currentThread().getContextClassLoader();
		InputStream is = loader.getResourceAsStream("GloblSettings.properties");
		try {
			props.load(new FileInputStream("GloblSettings.properties"));
			Settings.setProps(props);

		} catch (IOException e) {

		}

	}

	public void initializeWebDriver() {
		String browser = Settings.getProps().getProperty("browser");
		if (browser.equalsIgnoreCase("Chrome")) {
			ChromeOptions chromeoptions = new ChromeOptions();
			WebDriverManager.chromedriver().setup();
			WebDriver driver = new ChromeDriver(chromeoptions);
			driver.manage().window().maximize();
			DriverManager.getInstance().setWebDriver(driver);

		}

	}
}
