package com.in.utilities;

import java.util.Map;

import org.json.simple.*;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.remote.RemoteWebDriver;
import io.cucumber.java.Scenario;
public class DriverManager {
	
	private static DriverManager instance=new DriverManager();
	
	private JSONObject pageData;
	private String FeatureName;
	private String ScenarioName;
	private Scenario Scenario;
	private Map JSON;
	private WebDriver webDriver;
	private String browserName;
	
	public String getBrowserName() {
		return browserName;
	}
	public void setBrowserName(String browserName) {
		this.browserName = browserName;
	}
	public static DriverManager getInstance() {
		return instance;
	}
	public static void setInstance(DriverManager instance) {
		DriverManager.instance = instance;
	}
	public WebDriver getWebDriver() {
		return webDriver;
	}
	
	public void setWebDriver(WebDriver driver) {
		this.webDriver=driver;
		
	}
	public JSONObject getPageData() {
		return pageData;
	}
	public void setPageData(JSONObject pageData) {
		this.pageData = pageData;
	}
	public String getFeatureName() {
		return FeatureName;
	}
	public void setFeatureName(String featureName) {
		FeatureName = featureName;
	}
	public String getScenarioName() {
		return ScenarioName;
	}
	public void setScenarioName(String scenarioName) {
		ScenarioName = scenarioName;
	}
	public Scenario getScenario() {
		return Scenario;
	}
	public void setScenario(Scenario scenario) {
		Scenario = scenario;
	}
	public Map getJSON() {
		return JSON;
	}
	public void setJSON(Map jSON) {
		JSON = jSON;
	}
	

}
