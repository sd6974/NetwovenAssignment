package com.in.utilities;

import java.util.Properties;

public class Settings {
	private static Properties props = new Properties();

	public static Properties getInstance() {
		return props;
	}

	public static Properties getProps() {
		return props;
	}

	public static void setProps(Properties props) {
		Settings.props = props;
	}
}
