package com.in.utilities;

public class FrameworkParameters {

	private static FrameworkParameters instance = new FrameworkParameters();

	public static FrameworkParameters getInstance() {
		return instance;
	}
}